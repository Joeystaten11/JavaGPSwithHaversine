/**
* City.java Apr 9, 2017
*
* Copyright (C) 2017 Joseph J. Staten
* Elon University, Elon, NC 27244
*/
package edu.elon.distance;


/**
 * @author josephstaten
 *
 */
public class City implements Comparable {

  private String cityName;
  private double lat;
  private double milage;
  private double longi;

  public City(String cityName, double lat, double longi, double milage) {
    super();
    this.cityName = cityName;
    this.lat = lat;
    this.longi = longi;
    this.milage = milage;

  }

  @Override
  public int compareTo(Object aO) {
    // TODO Auto-generated method stub
    return 7;
  }

  /**
   * @return the cityName
   */
  public String getCityName() {
    return cityName;
  }

  /**
   * @return the lat
   */
  public double getLat() {
    return lat;
  }

  /**
   * @return the longi
   */
  public double getLongi() {
    return longi;
  }

  /**
   * @param aCityName
   *          the cityName to set
   */
  public void setCityName(String aCityName) {
    cityName = aCityName;
  }

  /**
   * @param aLat
   *          the lat to set
   */
  public void setLat(double aLat) {
    lat = aLat;
  }

  /**
   * @param aLongi
   *          the longi to set
   */
  public void setLongi(double aLongi) {
    longi = aLongi;
  }

  /**
   * @param aMilage
   *          the milage to set
   */
  public void setMilage(double aMilage) {
    milage = aMilage;
  }

  double compareTo(City compareMilage) {

    double compareCity = compareMilage.getMilage();
    // return this.milage - compareCity;
    if (compareCity < 0) {
      return 1;
    }
    if (compareCity > 0) {
      return -1;
    }
    return 0;
  }

  private double getMilage() {
    return milage;
  }
}
