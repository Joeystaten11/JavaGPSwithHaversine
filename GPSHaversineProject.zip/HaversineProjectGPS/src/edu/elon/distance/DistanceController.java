/**
 * DistanceController.java April 1st, 2017
 *
 * Copyright (C) 2017 Joseph J. Staten & Eddie Staten
 * Elon University, Elon, NC 27244
 */
package edu.elon.distance;


import java.io.File;
import java.util.ArrayList;


/**
 * Controls creation and interactions between View and Model objects.
 *
 * @author josephstaten
 * @author EddieStaten
 *
 */
public class DistanceController {
  private DistanceModel model;
  private DistanceGuiView view;
  private File input = null;
  private ArrayList<City> cityList;

  /**
   * Tells the program to run
   *
   * Tells the DistanceGuiView to prompt the user for a file, then his values,
   * then tells model to add to arrays and then tells model to create a list of
   * names and locations and calculate the distances apart from the file
   * locations and the user.Then asks view to display result.
   */
  private String fileName = "";

  /**
   * Creates a constructor with no arguments that instantiates an instance of a
   * DistanceModel class and an instance of a DistanceGuiView class.
   */
  public DistanceController() {
    view = new DistanceGuiView();
    model = new DistanceModel();

  }

  public void go() {
    boolean correctFile = false;
    while (!correctFile) { // THIS JUST MAKES IT KEEP LOOPING WHEN YOU CLICK OUT

      try {
        input = view.getFile();
        fileName = input.toString();

        if (!fileName.substring(fileName.length() - 3).equals("csv")) {

          view.showError(fileName);
          go();

        }
        model.analyzeData(input);

        // model.sort();

      } catch (Exception exception) {
        System.out.print(fileName.substring(fileName.length() - 3));
        view.showError(fileName);
        go();
      }

      correctFile = true;
    }

    String userName = view.askForName();

    String userLatitude = view.getLatitude();
    double uLatitude = Double.parseDouble(userLatitude);
    // model.getUserLat(uLatitude);

    String userLongitude = view.getLongitude();
    double uLongitude = Double.parseDouble(userLongitude);
    // model.getUserLong(uLongitude);

    int amountOfCities = view.getNumberOfClosestCities();
    model.getAmountOfCities(amountOfCities);
    model.getDistance(uLatitude, uLongitude);
    /*
     * for (int i = 0; i < milage.length; i++) { City cityInfo = new
     * City(model.getName(), model.getLat(), model.getLongi(),
     * model.getMilage()); }
     */
    model.sort100();
    String nameList = model.getNames();

    view.displayNames(nameList);

    go();

  }

}
