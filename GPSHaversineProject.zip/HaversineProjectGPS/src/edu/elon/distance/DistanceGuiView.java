/**
* DistanceView.java April 1st, 2017
*
* Copyright (C) 2017 Joseph J. Staten & Eddie Staten
* Elon University, Elon, NC 27244
*/
package edu.elon.distance;


import java.awt.Font;
import java.io.File;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;


/**
 * Prompts user for inputs and displays results to user
 *
 * @author josephstaten
 * @author Eddiestaten
 *
 *
 */
public class DistanceGuiView {

  private String userName = "";
  private int cities = 0;

  private JFileChooser chooser = new JFileChooser();

  private String line = "";

  private File selectedFile = null;

  private String title = "";

  /**
   * creates a no argument constructor.
   */
  public DistanceGuiView() {

  }

  /**
   * Asks the user for their name
   *
   * @return string of the user's name
   */
  public String askForName() {
    UIManager.put("OptionPane.messageFont",
        new FontUIResource(new Font("Monospaced", Font.PLAIN, 12)));
    String message = "Enter your name";
    String title = "Username Entry";
    userName = JOptionPane.showInputDialog(null, message, title,
        JOptionPane.INFORMATION_MESSAGE);
    if (userName == null) {
      System.exit(0);
    }
    return userName;

  }

  /**
   * Displays to the user all of the location names and coordinates in a table
   *
   * @param aNameList
   */

  public void displayNames(String aNameList) {
    UIManager.put("OptionPane.messageFont",
        new FontUIResource(new Font("Monospaced", Font.PLAIN, 12)));

    String title = "Closest Cities";
    JOptionPane.showMessageDialog(null, "Closest " + cities + " to "
        + userName + " are:" + "\n" + aNameList, title,
        JOptionPane.INFORMATION_MESSAGE);

  }

  /**
   * gets a files from the users computer
   *
   * @return A userselected file
   * @throws IOException
   */
  public File getFile() throws IOException {
    JFileChooser chooser = new JFileChooser();
    chooser.setDialogTitle("Filename of City Locations");
    if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
      selectedFile = chooser.getSelectedFile();
    } else {
      System.exit(0);
    }

    return selectedFile;
  }

  /**
   * Prompts the user for latitude using JOptionpan. The assumption is that the
   * user always enters a valid double
   *
   * @return latitude
   */

  public String getLatitude() {
    UIManager.put("OptionPane.messageFont",
        new FontUIResource(new Font("Monospaced", Font.PLAIN, 12)));
    String message = "Enter your latitude";
    String title = "Latitude Entry";
    String latitude = JOptionPane.showInputDialog(null, message, title,
        JOptionPane.INFORMATION_MESSAGE);
    if (latitude == null) {
      System.exit(0);
    }

    return latitude;

  }

  /**
   * Prompts the user for longitude using JOptionpane. The assumption is that
   * the user always enters a valid double
   *
   * @return longitude
   */

  public String getLongitude() {
    UIManager.put("OptionPane.messageFont",
        new FontUIResource(new Font("Monospaced", Font.PLAIN, 12)));
    String message = "Enter your longitude";
    String title = "Longitude Entry";
    String longitude = JOptionPane.showInputDialog(null, message, title,
        JOptionPane.INFORMATION_MESSAGE);
    if (longitude == null) {
      System.exit(0);
    }
    return longitude;

  }

  /**
   * Prompts the user for number of closest cities the user wants to be returned
   *
   * @return a double of $ of cities
   */
  public int getNumberOfClosestCities() {

    String message = "Enter desired number of closest cities to your location";
    String title = "Number of Closest Cities";
    String amountOfCities = JOptionPane.showInputDialog(null, message,
        title, JOptionPane.INFORMATION_MESSAGE);
    if (amountOfCities == null) {
      System.exit(0);
    }

    cities = Integer.parseInt(amountOfCities);

    return cities;

  }

  /**
   * Supposed to use with the control to show error
   */
  public void showError(String filename) {
    String fileName = filename;
    String title = "Invalid File";
    JOptionPane.showMessageDialog(null,
        "The file " + fileName + " is not in proper format", title,
        JOptionPane.INFORMATION_MESSAGE);
  }

}
