/**
* DistanceModel.java April 1st, 2017
*
* Copyright (C) 2017 Joseph J. Staten & Eddie Staten
* Elon University, Elon, NC 27244
*
* Used snippets of Haversine code found
*  at:
*/

package edu.elon.distance;


import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


/**
 *
 * Stores an array of names and coordinates and provides methods to add to the
 * arrays and to calculate the farthest distance from two locations
 *
 * @author josephstaten
 * @author EddieStaten
 */

public class DistanceModel {

  private final double R = 3959; // In Miles!
  private ArrayList<Double> lat = new ArrayList<Double>();
  private ArrayList<Double> longitude = new ArrayList<Double>();
  private ArrayList<Double> lat2 = new ArrayList<Double>();
  private ArrayList<Double> longitude2 = new ArrayList<Double>();
  private ArrayList<String> name = new ArrayList<String>();
  private ArrayList<String> names = new ArrayList<String>();

  private double[] milage;
  private double[] milage2;

  private double distance = 0;
  private String apart = "";

  // private double userLat = 0;

  // private double userLong = 0;

  private int amountOfCities = 0;

  // String[] names;

  /**
   * Meant to sort the mileage
   *
   * @param array
   * @return a sorted mileage from smallest to largest
   */

  /**
   * Constructs a blank constructor
   */
  public DistanceModel() {

  }

  /**
   * Stores the provided latitude to the next empty spot in the array.
   *
   * @param latitude
   */
  public void addToArrayLat(double latitude) {

    lat.add(latitude);
  }

  /**
   * Stores the provided longitude to the next empty spot in the array.
   *
   * @param longitude
   */
  public void addToArrayLong(double longi) {
    longitude.add(longi);
  }

  /**
   * Takes a file and splits each line by commas, then adds each element to an
   * array list
   *
   * @param selectedFile
   *
   * @param name
   * @return an arrayList of the type String
   */

  public void analyzeData(File selectedFile) throws Exception {
    Scanner in = null;
    String data = "";
    try {
      in = new Scanner(selectedFile);
      // skip the first two lines
      in.nextLine();
      in.nextLine();

      while (in.hasNextLine()) {
        data = in.nextLine();
        String[] columns = data.split(",");

        lat.add(Double.parseDouble(columns[5]));
        longitude.add(Double.parseDouble(columns[6]));
        name.add(columns[3]);
      }
    } catch (Exception exception) {
    }
    milage = new double[lat.size()];
    milage2 = new double[lat.size()];

  }

  /**
   * Takes the amount of Cities a user provided and adds it to program
   *
   * @param amount
   */
  public void getAmountOfCities(int amount) {
    amountOfCities = amount;

  }

  /**
   * calculates the farthest distance from two locations, using the haversine
   * method
   *
   *
   *
   * @returns a arrayList of type string that is the distance betweeen the user
   *          and the location of the file items
   */
  public void getDistance(double userLat, double userLong) {

    for (int j = 0; j < lat.size(); j++) {

      distance = haversine(userLat, userLong, lat.get(j),
          longitude.get(j));

      // Double listance = String.format("%.2f", distance);
      milage[j] = distance;
      milage2[j] = distance;

    }

  }

  public double getLat() {
    int i = 0;
    double cLat = lat.get(i);
    i++;
    return cLat;

  }

  public double getLongi() {
    int i = 0;
    double cLong = longitude.get(i);
    i++;
    return cLong;

  }

  public double getMilage() {
    int i = 0;
    double cMil = milage[i];
    i++;
    return cMil;

  }

  public String getName() {
    int i = 0;
    String cName = name.get(i);
    i++;
    return cName;

  }

  /**
   * Creates a string that we call nameList that creates a table like image,
   * holding each location name and their coordinates and mileage from user
   *
   * @return nameList
   */

  public String getNames() {

    String nameList = "Location           Latitude       Longitude      Mileage";
    nameList = nameList + "\n";
    for (int i = 0; i < amountOfCities; i++) {
      nameList = nameList + String.format("%-20s", names.get(i));

      nameList = nameList + String.format("%-15s", lat2.get(i));
      nameList = nameList + String.format("%-15s", longitude2.get(i));

      nameList = nameList + String.format("%-15s", milage2[i]);
      nameList = nameList + "\n";

    }

    nameList = nameList + "\n";
    return nameList;

  }

  /**
   * Takes the user inputed latitude and uses it in the program to see how far
   * the user is from other locations nearby
   *
   * @param value
   */
  // public void getUserLat(double value) {
  // userLat = value;

  // }

  /**
   * Takes the user inputed longitude and uses it in the program to see how far
   * the user is from other locations nearby
   *
   * @param value
   */
  // public void getUserLong(double value) {
  // userLong = value;
  // }

  // secondSorter = new DistanceModel(second);
  // first.length;
  // secondSorter.sort();

  // merge(first, second);

  /**
   * Uses the Haversine method to take in two locations coordinates and
   * calculates the distance from the two location in miles
   *
   * @param lat1
   * @param lon1
   * @param lat2
   * @param lon2
   * @return distance from two locations in miles
   */
  public double haversine(double lat1, double lon1, double lat2,
      double lon2) {

    double dLat = Math.toRadians(lat2 - lat1);
    double dLon = Math.toRadians(lon2 - lon1);
    lat1 = Math.toRadians(lat1);
    lat2 = Math.toRadians(lat2);

    double a = Math.pow(Math.sin(dLat / 2), 2)
        + Math.pow(Math.sin(dLon / 2), 2) * Math.cos(lat1)
            * Math.cos(lat2);
    double c = 2 * Math.asin(Math.sqrt(a));
    return R * c;
  }
  /*
   * public static double haversine(double lat1, double lon1, double lat2,
   * double lon2) { double dLat = Math.toRadians(lat2 - lat1); double dLon
   * =Math.toRadians(lon2 - lon1); lat1 = Math.toRadians(lat1); lat2 =
   * Math.toRadians(lat2);
   *
   * double a = Math.pow(Math.sin(dLat / 2),2) + Math.pow(Math.sin(dLon / 2),2)
   * * Math.cos(lat1) * Math.cos(lat2); double c = 2 * Math.asin(Math.sqrt(a));
   * return R * c; }
   *
   */

  public int search(double aMilage) {
    for (int i = 0; i < milage.length; i++) {
      if (milage[i] == aMilage) {
        return i;
      }
    }
    return -1;
  }

  public void sort100() {
    int pos1 = 0;
    Arrays.sort(milage2);
    for (int i = 0; i < milage.length; i++) {

      pos1 = search(milage2[i]);
      names.add(name.get(pos1));
      lat2.add(lat.get(pos1));
      longitude2.add(longitude.get(pos1));
      // names = new String[milage.length];

    }

  }

}
