/**
* Main.java April 1st, 2017
*
* Copyright (C) 2017 Joseph J. Staten & Eddie Staten
* Elon University, Elon, NC 27244
*/
package edu.elon.distance;


import javax.swing.SwingUtilities;


/**
 * * Utility class to provide main method to start application.
 *
 * @author josephstaten
 * @author EddieStaten
 *
 */
public class Main {

  /**
   * Driver method for JVM to call to start application
   *
   * @param args
   *          string array of command line arguments not used by this
   *          application.
   */
  public static void main(String[] args) {

    SwingUtilities.invokeLater(new Runnable() {
      @Override
      public void run() {

        DistanceController controller = new DistanceController();
        DistanceGuiView view = new DistanceGuiView();
        controller.go();

      }
    });

  }
}
